# Movie Collection Viewer

This is a React application that fetches and displays movie collection details from the TMDB API.

## Features
- Fetches collection details using `fetch()`.
- Displays movie posters, titles, and release dates in a responsive grid (RecyclerView style).
- Shows loading and error states.
- Uses functional components and Hooks (`useState`, `useEffect`).

## Configuration
Before running the application, you must provide a valid TMDB API Key.

1. Open `src/App.jsx`.
2. Locate the `API_KEY` constant and replace it with your API key:
   ```javascript
   const API_KEY = "YOUR_API_KEY_HERE";
   ```
   (Note: A placeholder or sample key might be present. Please ensure it is valid.)

## Running the Application
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the development server:
   ```bash
   npm run dev
   ```
3. Open the URL shown in the terminal (usually `http://localhost:5173`).

## Project Structure
- `src/App.jsx`: Main application logic and data fetching.
- `src/MovieList.jsx`: Component to render the grid of movies.
- `src/App.css`: Styles for the application.
