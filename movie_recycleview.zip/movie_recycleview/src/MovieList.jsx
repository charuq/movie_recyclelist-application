import React from 'react';
import './App.css'; // Assuming styles are global or imported here

const MovieList = ({ movies }) => {
  if (!movies || movies.length === 0) {
    return <div className="no-movies">No movies found.</div>;
  }

  return (
    <div className="movie-grid">
      {movies.map((movie) => (
        <div key={movie.id} className="movie-card">
          <img 
            src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`} 
            alt={movie.title} 
            className="movie-poster"
            loading="lazy"
          />
          <div className="movie-info">
            <h3 className="movie-title">{movie.title}</h3>
            <p className="movie-date">Release Date: {movie.release_date}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MovieList;
