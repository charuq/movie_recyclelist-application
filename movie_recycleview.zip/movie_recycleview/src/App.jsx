import React, { useState, useEffect } from 'react';
import './App.css';
import MovieList from './MovieList';

const App = () => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Configuration - Replace with your actual API key
  const API_KEY = "ab7cf1f3a9fd44ce8fba3e74e3afa90e";
  const COLLECTION_ID = 10; // Star Wars Collection

  useEffect(() => {
    const BASE_URL = "https://api.themoviedb.org/3";
    const URL = `${BASE_URL}/collection/${COLLECTION_ID}?api_key=${API_KEY}`;

    const fetchMovies = async () => {
      try {
        setLoading(true);
        console.log(`Fetching movies for collection ${COLLECTION_ID} with key ${API_KEY.slice(0, 4)}...`);
        const response = await fetch(URL, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          }
        });

        if (!response.ok) {
          throw new Error(`Error: ${response.status} - ${response.statusText}`);
        }

        const data = await response.json();

        // The API returns 'parts' array which contains the movies
        if (data.parts) {
          setMovies(data.parts);
        } else {
          console.warn("No 'parts' found in response", data);
          setMovies([]);
        }
      } catch (err) {
        console.error("Fetch error:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchMovies();
  }, [API_KEY, COLLECTION_ID]); // Dependencies

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>Movie Collection: Star Wars</h1>
      </header>

      <main>
        {loading && <div className="loading">Loading movies...</div>}
        {error && <div className="error">Error: {error}. Please ensure your API key is correct.</div>}

        {!loading && !error && <MovieList movies={movies} />}
      </main>
    </div>
  );
};

export default App;
